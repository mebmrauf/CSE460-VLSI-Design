DSCH 2.7a
VERSION 10/27/2025 5:24:20 AM
BB(-95,-25,214,30)
SYM  #DLatch
BB(15,-20,55,10)
TITLE 25 -22  #DLatch
MODEL 6000
PROP                                                                                                                                                                                                           
REC(20,-15,30,20,r)
VIS 5
PIN(15,0,0.000,0.000)clk
PIN(15,-10,0.000,0.000)D
PIN(55,-10,0.060,0.700)Q
PIN(55,0,0.060,0.490)_Q
LIG(15,0,20,0)
LIG(15,-10,20,-10)
LIG(50,-10,55,-10)
LIG(50,0,55,0)
LIG(20,-15,20,5)
LIG(20,-15,50,-15)
LIG(50,-15,50,5)
LIG(50,5,20,5)
VLG  module DLatch( clk,D,Q,_Q);
VLG   input clk,D;
VLG   output Q,_Q;
VLG   wire w9,w10,w11,w12;
VLG   not #(228) notgate(w2,w1);
VLG   nand #(48) nandgate(_Q,Q,w4);
VLG   nand #(41) nandgate(w4,clk,w2);
VLG   nand #(41) nandgate(w8,D,clk);
VLG   nand #(48) nandgate(Q,w8,_Q);
VLG   pmos #(30) pmos_no1(w2,vdd,w1); //  
VLG   nmos #(30) nmos_no2(w2,vss,w1); //  
VLG   pmos #(47) pmos_na3(_Q,vdd,w4); //  
VLG   pmos #(47) pmos_na4(_Q,vdd,Q); //  
VLG   nmos #(47) nmos_na5(_Q,w9,Q); //  
VLG   nmos #(12) nmos_na6(w9,vss,w4); //  
VLG   pmos #(40) pmos_na7(w4,vdd,w2); //  
VLG   pmos #(40) pmos_na8(w4,vdd,clk); //  
VLG   nmos #(40) nmos_na9(w4,w10,clk); //  
VLG   nmos #(12) nmos_na10(w10,vss,w2); //  
VLG   pmos #(40) pmos_na11(w8,vdd,clk); //  
VLG   pmos #(40) pmos_na12(w8,vdd,D); //  
VLG   nmos #(40) nmos_na13(w8,w11,D); //  
VLG   nmos #(12) nmos_na14(w11,vss,clk); //  
VLG   pmos #(47) pmos_na15(Q,vdd,_Q); //  
VLG   pmos #(47) pmos_na16(Q,vdd,w8); //  
VLG   nmos #(47) nmos_na17(Q,w12,w8); //  
VLG   nmos #(12) nmos_na18(w12,vss,_Q); //  
VLG  endmodule
FSYM
SYM  #DLatch
BB(120,-20,160,10)
TITLE 130 -22  #DLatch
MODEL 6000
PROP                                                                                                                                                                                                           
REC(125,-15,30,20,r)
VIS 5
PIN(120,0,0.000,0.000)clk
PIN(120,-10,0.000,0.000)D
PIN(160,-10,0.060,0.560)Q
PIN(160,0,0.060,0.560)_Q
LIG(120,0,125,0)
LIG(120,-10,125,-10)
LIG(155,-10,160,-10)
LIG(155,0,160,0)
LIG(125,-15,125,5)
LIG(125,-15,155,-15)
LIG(155,-15,155,5)
LIG(155,5,125,5)
VLG  module DLatch( clk,D,Q,_Q);
VLG   input clk,D;
VLG   output Q,_Q;
VLG   wire w9,w10,w11,w12;
VLG   not #(228) notgate(w2,w1);
VLG   nand #(48) nandgate(_Q,Q,w4);
VLG   nand #(41) nandgate(w4,clk,w2);
VLG   nand #(41) nandgate(w8,D,clk);
VLG   nand #(48) nandgate(Q,w8,_Q);
VLG   pmos #(30) pmos_no1(w2,vdd,w1); //  
VLG   nmos #(30) nmos_no2(w2,vss,w1); //  
VLG   pmos #(47) pmos_na3(_Q,vdd,w4); //  
VLG   pmos #(47) pmos_na4(_Q,vdd,Q); //  
VLG   nmos #(47) nmos_na5(_Q,w9,Q); //  
VLG   nmos #(12) nmos_na6(w9,vss,w4); //  
VLG   pmos #(40) pmos_na7(w4,vdd,w2); //  
VLG   pmos #(40) pmos_na8(w4,vdd,clk); //  
VLG   nmos #(40) nmos_na9(w4,w10,clk); //  
VLG   nmos #(12) nmos_na10(w10,vss,w2); //  
VLG   pmos #(40) pmos_na11(w8,vdd,clk); //  
VLG   pmos #(40) pmos_na12(w8,vdd,D); //  
VLG   nmos #(40) nmos_na13(w8,w11,D); //  
VLG   nmos #(12) nmos_na14(w11,vss,clk); //  
VLG   pmos #(47) pmos_na15(Q,vdd,_Q); //  
VLG   pmos #(47) pmos_na16(Q,vdd,w8); //  
VLG   nmos #(47) nmos_na17(Q,w12,w8); //  
VLG   nmos #(12) nmos_na18(w12,vss,_Q); //  
VLG  endmodule
FSYM
SYM  #notgate
BB(-65,-10,-25,10)
TITLE -55 -12  #notgate
MODEL 6000
PROP                                                                                                                                                                                                           
REC(-60,-5,30,10,r)
VIS 5
PIN(-65,0,0.000,0.000)A
PIN(-25,0,2.000,0.560)Y
LIG(-65,0,-60,0)
LIG(-30,0,-25,0)
LIG(-60,-5,-60,5)
LIG(-60,-5,-30,-5)
LIG(-30,-5,-30,5)
LIG(-30,5,-60,5)
VLG  module notgate( A,Y);
VLG   input A;
VLG   output Y;
VLG   pmos #(17) pmos(Y,vdd,A); // 2.0u 0.12u
VLG   nmos #(17) nmos(Y,vss,A); // 1.0u 0.12u
VLG  endmodule
FSYM
SYM  #button1
BB(-9,-24,0,-16)
TITLE -5 -20  #button
MODEL 59
PROP                                                                                                                                                                                                           
REC(-8,-23,6,6,r)
VIS 1
PIN(0,-20,0.000,0.000)D
LIG(-1,-20,0,-20)
LIG(-9,-16,-9,-24)
LIG(-1,-16,-9,-16)
LIG(-1,-24,-1,-16)
LIG(-9,-24,-1,-24)
LIG(-8,-17,-8,-23)
LIG(-2,-17,-8,-17)
LIG(-2,-23,-2,-17)
LIG(-8,-23,-2,-23)
FSYM
SYM  #clock1
BB(-95,-3,-80,3)
TITLE -90 0  #clock
MODEL 69
PROP   10.000 10.000                                                                                                                                                                                                       
REC(-93,-2,6,4,r)
VIS 1
PIN(-80,0,1.500,0.560)clk
LIG(-85,0,-80,0)
LIG(-90,-2,-92,-2)
LIG(-86,-2,-88,-2)
LIG(-85,-3,-85,3)
LIG(-95,3,-95,-3)
LIG(-90,2,-90,-2)
LIG(-88,-2,-88,2)
LIG(-88,2,-90,2)
LIG(-92,2,-94,2)
LIG(-92,-2,-92,2)
LIG(-85,3,-95,3)
LIG(-85,-3,-95,-3)
FSYM
SYM  #light1
BB(183,-25,189,-11)
TITLE 185 -11  #light
MODEL 49
PROP                                                                                                                                                                                                           
REC(184,-24,4,4,r)
VIS 1
PIN(185,-10,0.000,0.000)Q
LIG(188,-19,188,-24)
LIG(188,-24,187,-25)
LIG(184,-24,184,-19)
LIG(187,-14,187,-17)
LIG(186,-14,189,-14)
LIG(186,-12,188,-14)
LIG(187,-12,189,-14)
LIG(183,-17,189,-17)
LIG(185,-17,185,-10)
LIG(183,-19,183,-17)
LIG(189,-19,183,-19)
LIG(189,-17,189,-19)
LIG(185,-25,184,-24)
LIG(187,-25,185,-25)
FSYM
SYM  #light2
BB(208,-15,214,-1)
TITLE 210 -1  #light
MODEL 49
PROP                                                                                                                                                                                                           
REC(209,-14,4,4,r)
VIS 1
PIN(210,0,0.000,0.000)-Q
LIG(213,-9,213,-14)
LIG(213,-14,212,-15)
LIG(209,-14,209,-9)
LIG(212,-4,212,-7)
LIG(211,-4,214,-4)
LIG(211,-2,213,-4)
LIG(212,-2,214,-4)
LIG(208,-7,214,-7)
LIG(210,-7,210,0)
LIG(208,-9,208,-7)
LIG(214,-9,208,-9)
LIG(214,-7,214,-9)
LIG(210,-15,209,-14)
LIG(212,-15,210,-15)
FSYM
LIG(55,-10,120,-10)
LIG(5,-20,0,-20)
LIG(-65,0,-65,30)
LIG(-65,30,120,30)
LIG(120,0,120,30)
LIG(-25,0,15,0)
LIG(160,-10,185,-10)
LIG(160,0,210,0)
LIG(-65,0,-80,0)
LIG(15,-10,5,-10)
LIG(5,-10,5,-20)
FFIG F:\dsch2\Dflipflop.sch

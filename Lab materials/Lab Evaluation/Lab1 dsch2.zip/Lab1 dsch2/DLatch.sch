DSCH 2.7a
VERSION 10/27/2025 5:16:36 AM
BB(-104,-25,154,75)
SYM  #notgate
BB(-75,45,-35,65)
TITLE -65 43  #notgate
MODEL 6000
PROP                                                                                                                                                                                                           
REC(-70,50,30,10,r)
VIS 5
PIN(-75,55,0.000,0.000)A
PIN(-35,55,2.000,0.280)Y
LIG(-75,55,-70,55)
LIG(-40,55,-35,55)
LIG(-70,50,-70,60)
LIG(-70,50,-40,50)
LIG(-40,50,-40,60)
LIG(-40,60,-70,60)
VLG  module notgate( A,Y);
VLG   input A;
VLG   output Y;
VLG   pmos #(17) pmos(Y,vdd,A); // 2.0u 0.12u
VLG   nmos #(17) nmos(Y,vss,A); // 1.0u 0.12u
VLG  endmodule
FSYM
SYM  #nandgate
BB(65,45,105,75)
TITLE 75 43  #nandgate
MODEL 6000
PROP                                                                                                                                                                                                           
REC(70,50,30,20,r)
VIS 5
PIN(65,55,0.000,0.000)A
PIN(65,65,0.000,0.000)B
PIN(105,55,0.060,0.420)Y
LIG(65,55,70,55)
LIG(65,65,70,65)
LIG(100,55,105,55)
LIG(70,50,70,70)
LIG(70,50,100,50)
LIG(100,50,100,70)
LIG(100,70,70,70)
VLG  module nandgate( A,B,Y);
VLG   input A,B;
VLG   output Y;
VLG   pmos #(24) pmos(Y,vdd,B); // 2.0u 0.12u
VLG   pmos #(24) pmos(Y,vdd,A); // 2.0u 0.12u
VLG   nmos #(24) nmos(Y,w4,A); // 1.0u 0.12u
VLG   nmos #(10) nmos(w4,vss,B); // 1.0u 0.12u
VLG  endmodule
FSYM
SYM  #nandgate
BB(-5,45,35,75)
TITLE 5 43  #nandgate
MODEL 6000
PROP                                                                                                                                                                                                           
REC(0,50,30,20,r)
VIS 5
PIN(-5,55,0.000,0.000)A
PIN(-5,65,0.000,0.000)B
PIN(35,55,0.060,0.350)Y
LIG(-5,55,0,55)
LIG(-5,65,0,65)
LIG(30,55,35,55)
LIG(0,50,0,70)
LIG(0,50,30,50)
LIG(30,50,30,70)
LIG(30,70,0,70)
VLG  module nandgate( A,B,Y);
VLG   input A,B;
VLG   output Y;
VLG   pmos #(24) pmos(Y,vdd,B); // 2.0u 0.12u
VLG   pmos #(24) pmos(Y,vdd,A); // 2.0u 0.12u
VLG   nmos #(24) nmos(Y,w4,A); // 1.0u 0.12u
VLG   nmos #(10) nmos(w4,vss,B); // 1.0u 0.12u
VLG  endmodule
FSYM
SYM  #nandgate
BB(-15,-20,25,10)
TITLE -5 -22  #nandgate
MODEL 6000
PROP                                                                                                                                                                                                           
REC(-10,-15,30,20,r)
VIS 5
PIN(-15,-10,0.000,0.000)A
PIN(-15,0,0.000,0.000)B
PIN(25,-10,0.060,0.350)Y
LIG(-15,-10,-10,-10)
LIG(-15,0,-10,0)
LIG(20,-10,25,-10)
LIG(-10,-15,-10,5)
LIG(-10,-15,20,-15)
LIG(20,-15,20,5)
LIG(20,5,-10,5)
VLG  module nandgate( A,B,Y);
VLG   input A,B;
VLG   output Y;
VLG   pmos #(24) pmos(Y,vdd,B); // 2.0u 0.12u
VLG   pmos #(24) pmos(Y,vdd,A); // 2.0u 0.12u
VLG   nmos #(24) nmos(Y,w4,A); // 1.0u 0.12u
VLG   nmos #(10) nmos(w4,vss,B); // 1.0u 0.12u
VLG  endmodule
FSYM
SYM  #nandgate
BB(60,-20,100,10)
TITLE 70 -22  #nandgate
MODEL 6000
PROP                                                                                                                                                                                                           
REC(65,-15,30,20,r)
VIS 5
PIN(60,-10,0.000,0.000)A
PIN(60,0,0.000,0.000)B
PIN(100,-10,0.060,0.420)Y
LIG(60,-10,65,-10)
LIG(60,0,65,0)
LIG(95,-10,100,-10)
LIG(65,-15,65,5)
LIG(65,-15,95,-15)
LIG(95,-15,95,5)
LIG(95,5,65,5)
VLG  module nandgate( A,B,Y);
VLG   input A,B;
VLG   output Y;
VLG   pmos #(24) pmos(Y,vdd,B); // 2.0u 0.12u
VLG   pmos #(24) pmos(Y,vdd,A); // 2.0u 0.12u
VLG   nmos #(24) nmos(Y,w4,A); // 1.0u 0.12u
VLG   nmos #(10) nmos(w4,vss,B); // 1.0u 0.12u
VLG  endmodule
FSYM
SYM  #light1
BB(148,-25,154,-11)
TITLE 150 -11  #light
MODEL 49
PROP                                                                                                                                                                                                           
REC(149,-24,4,4,r)
VIS 1
PIN(150,-10,0.000,0.000)Q
LIG(153,-19,153,-24)
LIG(153,-24,152,-25)
LIG(149,-24,149,-19)
LIG(152,-14,152,-17)
LIG(151,-14,154,-14)
LIG(151,-12,153,-14)
LIG(152,-12,154,-14)
LIG(148,-17,154,-17)
LIG(150,-17,150,-10)
LIG(148,-19,148,-17)
LIG(154,-19,148,-19)
LIG(154,-17,154,-19)
LIG(150,-25,149,-24)
LIG(152,-25,150,-25)
FSYM
SYM  #light2
BB(138,30,144,44)
TITLE 140 44  #light
MODEL 49
PROP                                                                                                                                                                                                           
REC(139,31,4,4,r)
VIS 1
PIN(140,45,0.000,0.000)-Q
LIG(143,36,143,31)
LIG(143,31,142,30)
LIG(139,31,139,36)
LIG(142,41,142,38)
LIG(141,41,144,41)
LIG(141,43,143,41)
LIG(142,43,144,41)
LIG(138,38,144,38)
LIG(140,38,140,45)
LIG(138,36,138,38)
LIG(144,36,138,36)
LIG(144,38,144,36)
LIG(140,30,139,31)
LIG(142,30,140,30)
FSYM
SYM  #clock1
BB(-45,22,-30,28)
TITLE -40 25  #clock
MODEL 69
PROP   10.000 10.000                                                                                                                                                                                                       
REC(-43,23,6,4,r)
VIS 1
PIN(-30,25,1.500,0.280)clk
LIG(-35,25,-30,25)
LIG(-40,23,-42,23)
LIG(-36,23,-38,23)
LIG(-35,22,-35,28)
LIG(-45,28,-45,22)
LIG(-40,27,-40,23)
LIG(-38,23,-38,27)
LIG(-38,27,-40,27)
LIG(-42,27,-44,27)
LIG(-42,23,-42,27)
LIG(-35,28,-45,28)
LIG(-35,22,-45,22)
FSYM
SYM  #button1
BB(-104,-14,-95,-6)
TITLE -100 -10  #button
MODEL 59
PROP                                                                                                                                                                                                           
REC(-103,-13,6,6,r)
VIS 1
PIN(-95,-10,0.000,0.000)D
LIG(-96,-10,-95,-10)
LIG(-104,-6,-104,-14)
LIG(-96,-6,-104,-6)
LIG(-96,-14,-96,-6)
LIG(-104,-14,-96,-14)
LIG(-103,-7,-103,-13)
LIG(-97,-7,-103,-7)
LIG(-97,-13,-97,-7)
LIG(-103,-13,-97,-13)
FSYM
CNC(-15 25)
CNC(120 -10)
CNC(105 45)
LIG(-95,-10,-15,-10)
LIG(25,-10,60,-10)
LIG(60,0,60,30)
LIG(60,30,105,30)
LIG(105,30,105,45)
LIG(100,-10,120,-10)
LIG(120,-10,120,15)
LIG(120,15,75,15)
LIG(75,15,75,40)
LIG(75,40,50,40)
LIG(50,40,50,55)
LIG(50,55,65,55)
LIG(-15,0,-15,25)
LIG(-15,55,-5,55)
LIG(-35,55,-35,65)
LIG(-35,65,-5,65)
LIG(35,65,65,65)
LIG(-30,25,-15,25)
LIG(-15,25,-15,55)
LIG(105,45,105,55)
LIG(-85,-10,-85,55)
LIG(-85,55,-75,55)
LIG(105,45,140,45)
LIG(35,55,35,65)
LIG(120,-10,150,-10)
FFIG F:\dsch2\DLatch.sch

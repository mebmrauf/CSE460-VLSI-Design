DSCH 2.7a
VERSION 10/27/2025 7:08:32 AM
BB(106,-20,224,15)
SYM  #nandgate
BB(120,-15,160,15)
TITLE 130 -17  #nandgate
MODEL 6000
PROP                                                                                                                                                                                                           
REC(125,-10,30,20,r)
VIS 5
PIN(120,-5,0.000,0.000)A
PIN(120,5,0.000,0.000)B
PIN(160,-5,2.000,0.350)Y
LIG(120,-5,125,-5)
LIG(120,5,125,5)
LIG(155,-5,160,-5)
LIG(125,-10,125,10)
LIG(125,-10,155,-10)
LIG(155,-10,155,10)
LIG(155,10,125,10)
VLG  module nandgate( A,B,Y);
VLG   input A,B;
VLG   output Y;
VLG   pmos #(24) pmos(Y,vdd,B); // 2.0u 0.12u
VLG   pmos #(24) pmos(Y,vdd,A); // 2.0u 0.12u
VLG   nmos #(24) nmos(Y,w4,A); // 1.0u 0.12u
VLG   nmos #(10) nmos(w4,vss,B); // 1.0u 0.12u
VLG  endmodule
FSYM
SYM  #notgate
BB(170,-15,210,5)
TITLE 180 -17  #notgate
MODEL 6000
PROP                                                                                                                                                                                                           
REC(175,-10,30,10,r)
VIS 5
PIN(170,-5,0.000,0.000)A
PIN(210,-5,2.000,0.210)Y
LIG(170,-5,175,-5)
LIG(205,-5,210,-5)
LIG(175,-10,175,0)
LIG(175,-10,205,-10)
LIG(205,-10,205,0)
LIG(205,0,175,0)
VLG module notgate( A,Y);
VLG  input A;
VLG  output Y;
VLG  pmos #(17) pmos(Y,vdd,A); // 2.0u 0.12u
VLG  nmos #(17) nmos(Y,vss,A); // 1.0u 0.12u
VLG endmodule
FSYM
SYM  #light1
BB(218,-20,224,-6)
TITLE 220 -6  #light
MODEL 49
PROP                                                                                                                                                                                                           
REC(219,-19,4,4,r)
VIS 1
PIN(220,-5,0.000,0.000)Y
LIG(223,-14,223,-19)
LIG(223,-19,222,-20)
LIG(219,-19,219,-14)
LIG(222,-9,222,-12)
LIG(221,-9,224,-9)
LIG(221,-7,223,-9)
LIG(222,-7,224,-9)
LIG(218,-12,224,-12)
LIG(220,-12,220,-5)
LIG(218,-14,218,-12)
LIG(224,-14,218,-14)
LIG(224,-12,224,-14)
LIG(220,-20,219,-19)
LIG(222,-20,220,-20)
FSYM
SYM  #button2
BB(106,1,115,9)
TITLE 110 5  #button
MODEL 59
PROP                                                                                                                                                                                                           
REC(107,2,6,6,r)
VIS 1
PIN(115,5,0.000,0.000)B
LIG(114,5,115,5)
LIG(106,9,106,1)
LIG(114,9,106,9)
LIG(114,1,114,9)
LIG(106,1,114,1)
LIG(107,8,107,2)
LIG(113,8,107,8)
LIG(113,2,113,8)
LIG(107,2,113,2)
FSYM
SYM  #button1
BB(106,-9,115,-1)
TITLE 110 -5  #button
MODEL 59
PROP                                                                                                                                                                                                           
REC(107,-8,6,6,r)
VIS 1
PIN(115,-5,0.000,0.000)A
LIG(114,-5,115,-5)
LIG(106,-1,106,-9)
LIG(114,-1,106,-1)
LIG(114,-9,114,-1)
LIG(106,-9,114,-9)
LIG(107,-2,107,-8)
LIG(113,-2,107,-2)
LIG(113,-8,113,-2)
LIG(107,-8,113,-8)
FSYM
LIG(160,-5,170,-5)
LIG(115,-5,120,-5)
LIG(115,5,120,5)
LIG(210,-5,220,-5)
FFIG F:\dsch2\andgate.sch

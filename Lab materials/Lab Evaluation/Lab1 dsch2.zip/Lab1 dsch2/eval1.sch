DSCH 2.7a
VERSION 10/27/2025 7:28:44 AM
BB(-19,-105,229,-35)
SYM  #norgate
BB(155,-105,195,-75)
TITLE 165 -107  #norgate
MODEL 6000
PROP                                                                                                                                                                                                           
REC(160,-100,30,20,r)
VIS 5
PIN(155,-85,0.000,0.000)B
PIN(155,-95,0.000,0.000)A
PIN(195,-95,0.060,0.420)Y
LIG(155,-85,160,-85)
LIG(155,-95,160,-95)
LIG(190,-95,195,-95)
LIG(160,-100,160,-80)
LIG(160,-100,190,-100)
LIG(190,-100,190,-80)
LIG(190,-80,160,-80)
VLG  module norgate( B,A,Y);
VLG   input B,A;
VLG   output Y;
VLG   pmos #(10) pmos(w2,vdd,A); // 2.0u 0.12u
VLG   pmos #(24) pmos(Y,w2,B); // 2.0u 0.12u
VLG   nmos #(24) nmos(Y,vss,A); // 1.0u 0.12u
VLG   nmos #(24) nmos(Y,vss,B); // 1.0u 0.12u
VLG  endmodule
FSYM
SYM  #norgate
BB(155,-65,195,-35)
TITLE 165 -67  #norgate
MODEL 6000
PROP                                                                                                                                                                                                           
REC(160,-60,30,20,r)
VIS 5
PIN(155,-45,0.000,0.000)B
PIN(155,-55,0.000,0.000)A
PIN(195,-55,0.060,0.420)Y
LIG(155,-45,160,-45)
LIG(155,-55,160,-55)
LIG(190,-55,195,-55)
LIG(160,-60,160,-40)
LIG(160,-60,190,-60)
LIG(190,-60,190,-40)
LIG(190,-40,160,-40)
VLG  module norgate( B,A,Y);
VLG   input B,A;
VLG   output Y;
VLG   pmos #(10) pmos(w2,vdd,A); // 2.0u 0.12u
VLG   pmos #(24) pmos(Y,w2,B); // 2.0u 0.12u
VLG   nmos #(24) nmos(Y,vss,A); // 1.0u 0.12u
VLG   nmos #(24) nmos(Y,vss,B); // 1.0u 0.12u
VLG  endmodule
FSYM
SYM  #notgate
BB(30,-80,70,-60)
TITLE 40 -82  #notgate
MODEL 6000
PROP                                                                                                                                                                                                           
REC(35,-75,30,10,r)
VIS 5
PIN(30,-70,0.000,0.000)A
PIN(70,-70,0.060,0.560)Y
LIG(30,-70,35,-70)
LIG(65,-70,70,-70)
LIG(35,-75,35,-65)
LIG(35,-75,65,-75)
LIG(65,-75,65,-65)
LIG(65,-65,35,-65)
VLG  module notgate( A,Y);
VLG   input A;
VLG   output Y;
VLG   pmos #(17) pmos(Y,vdd,A); // 2.0u 0.12u
VLG   nmos #(17) nmos(Y,vss,A); // 1.0u 0.12u
VLG  endmodule
FSYM
SYM  #andgate
BB(85,-105,125,-75)
TITLE 95 -107  #andgate
MODEL 6000
PROP                                                                                                                                                                                                           
REC(90,-100,30,20,r)
VIS 5
PIN(85,-85,0.000,0.000)B
PIN(85,-95,0.000,0.000)A
PIN(125,-95,2.000,0.350)Y
LIG(85,-85,90,-85)
LIG(85,-95,90,-95)
LIG(120,-95,125,-95)
LIG(90,-100,90,-80)
LIG(90,-100,120,-100)
LIG(120,-100,120,-80)
LIG(120,-80,90,-80)
VLG  module andgate( B,A,Y);
VLG   input B,A;
VLG   output Y;
VLG   wire w5;
VLG   nand #(235) nandgate(w3,A,B);
VLG   not #(221) notgate(Y,w3);
VLG   pmos #(40) pmos_na1(w3,vdd,B); //  
VLG   pmos #(40) pmos_na2(w3,vdd,A); //  
VLG   nmos #(40) nmos_na3(w3,w5,A); //  
VLG   nmos #(12) nmos_na4(w5,vss,B); //  
VLG   pmos #(23) pmos_no5(Y,vdd,w3); //  
VLG   nmos #(23) nmos_no6(Y,vss,w3); //  
VLG  endmodule
FSYM
SYM  #andgate
BB(80,-65,120,-35)
TITLE 90 -67  #andgate
MODEL 6000
PROP                                                                                                                                                                                                           
REC(85,-60,30,20,r)
VIS 5
PIN(80,-45,0.000,0.000)B
PIN(80,-55,0.000,0.000)A
PIN(120,-55,2.000,0.350)Y
LIG(80,-45,85,-45)
LIG(80,-55,85,-55)
LIG(115,-55,120,-55)
LIG(85,-60,85,-40)
LIG(85,-60,115,-60)
LIG(115,-60,115,-40)
LIG(115,-40,85,-40)
VLG  module andgate( B,A,Y);
VLG   input B,A;
VLG   output Y;
VLG   wire w5;
VLG   nand #(235) nandgate(w3,A,B);
VLG   not #(221) notgate(Y,w3);
VLG   pmos #(40) pmos_na1(w3,vdd,B); //  
VLG   pmos #(40) pmos_na2(w3,vdd,A); //  
VLG   nmos #(40) nmos_na3(w3,w5,A); //  
VLG   nmos #(12) nmos_na4(w5,vss,B); //  
VLG   pmos #(23) pmos_no5(Y,vdd,w3); //  
VLG   nmos #(23) nmos_no6(Y,vss,w3); //  
VLG  endmodule
FSYM
SYM  #notgate
BB(10,-105,50,-85)
TITLE 20 -107  #notgate
MODEL 6000
PROP                                                                                                                                                                                                           
REC(15,-100,30,10,r)
VIS 5
PIN(10,-95,0.000,0.000)A
PIN(50,-95,0.060,0.350)Y
LIG(10,-95,15,-95)
LIG(45,-95,50,-95)
LIG(15,-100,15,-90)
LIG(15,-100,45,-100)
LIG(45,-100,45,-90)
LIG(45,-90,15,-90)
VLG  module notgate( A,Y);
VLG   input A;
VLG   output Y;
VLG   pmos #(17) pmos(Y,vdd,A); // 2.0u 0.12u
VLG   nmos #(17) nmos(Y,vss,A); // 1.0u 0.12u
VLG  endmodule
FSYM
SYM  #light1
BB(223,-105,229,-91)
TITLE 225 -91  #light
MODEL 49
PROP                                                                                                                                                                                                           
REC(224,-104,4,4,r)
VIS 1
PIN(225,-90,0.000,0.000)Q
LIG(228,-99,228,-104)
LIG(228,-104,227,-105)
LIG(224,-104,224,-99)
LIG(227,-94,227,-97)
LIG(226,-94,229,-94)
LIG(226,-92,228,-94)
LIG(227,-92,229,-94)
LIG(223,-97,229,-97)
LIG(225,-97,225,-90)
LIG(223,-99,223,-97)
LIG(229,-99,223,-99)
LIG(229,-97,229,-99)
LIG(225,-105,224,-104)
LIG(227,-105,225,-105)
FSYM
SYM  #light2
BB(223,-65,229,-51)
TITLE 225 -51  #light
MODEL 49
PROP                                                                                                                                                                                                           
REC(224,-64,4,4,r)
VIS 1
PIN(225,-50,0.000,0.000)QB
LIG(228,-59,228,-64)
LIG(228,-64,227,-65)
LIG(224,-64,224,-59)
LIG(227,-54,227,-57)
LIG(226,-54,229,-54)
LIG(226,-52,228,-54)
LIG(227,-52,229,-54)
LIG(223,-57,229,-57)
LIG(225,-57,225,-50)
LIG(223,-59,223,-57)
LIG(229,-59,223,-59)
LIG(229,-57,229,-59)
LIG(225,-65,224,-64)
LIG(227,-65,225,-65)
FSYM
SYM  #button2
BB(11,-74,20,-66)
TITLE 15 -70  #button
MODEL 59
PROP                                                                                                                                                                                                           
REC(12,-73,6,6,r)
VIS 1
PIN(20,-70,0.000,0.000)clk
LIG(19,-70,20,-70)
LIG(11,-66,11,-74)
LIG(19,-66,11,-66)
LIG(19,-74,19,-66)
LIG(11,-74,19,-74)
LIG(12,-67,12,-73)
LIG(18,-67,12,-67)
LIG(18,-73,18,-67)
LIG(12,-73,18,-73)
FSYM
SYM  #button1
BB(-19,-99,-10,-91)
TITLE -15 -95  #button
MODEL 59
PROP                                                                                                                                                                                                           
REC(-18,-98,6,6,r)
VIS 1
PIN(-10,-95,0.000,0.000)D
LIG(-11,-95,-10,-95)
LIG(-19,-91,-19,-99)
LIG(-11,-91,-19,-91)
LIG(-11,-99,-11,-91)
LIG(-19,-99,-11,-99)
LIG(-18,-92,-18,-98)
LIG(-12,-92,-18,-92)
LIG(-12,-98,-12,-92)
LIG(-18,-98,-12,-98)
FSYM
CNC(75 -70)
CNC(-5 -95)
LIG(125,-95,155,-95)
LIG(120,-55,135,-55)
LIG(135,-55,135,-45)
LIG(135,-45,155,-45)
LIG(195,-95,195,-75)
LIG(195,-75,155,-75)
LIG(155,-75,155,-55)
LIG(155,-85,145,-85)
LIG(145,-85,145,-70)
LIG(145,-70,195,-70)
LIG(195,-70,195,-55)
LIG(195,-55,210,-55)
LIG(210,-55,210,-50)
LIG(210,-50,225,-50)
LIG(195,-95,210,-95)
LIG(210,-95,210,-90)
LIG(210,-90,225,-90)
LIG(50,-95,85,-95)
LIG(85,-85,75,-85)
LIG(75,-85,75,-70)
LIG(75,-55,80,-55)
LIG(70,-70,75,-70)
LIG(75,-70,75,-55)
LIG(20,-70,30,-70)
LIG(-10,-95,-5,-95)
LIG(-5,-95,-5,-45)
LIG(-5,-95,10,-95)
LIG(-5,-45,80,-45)
FFIG F:\dsch2\eval1.sch
